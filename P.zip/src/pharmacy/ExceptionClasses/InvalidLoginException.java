package pharmacy.ExceptionClasses;

public class InvalidLoginException extends Exception{

    public InvalidLoginException(String msg) {
        super(msg);
    }
    
}
