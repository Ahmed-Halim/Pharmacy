package pharmacy.ExceptionClasses;

public class InvalidPrescriptionCode extends Exception{

    public InvalidPrescriptionCode(String string) {
        super(string);
    }
    
}
