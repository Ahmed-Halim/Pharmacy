
package pharmacy.ExceptionClasses;
public class RepeatedObjectException extends Exception{

    public RepeatedObjectException(String string) {
        super(string);
    }
    
}
